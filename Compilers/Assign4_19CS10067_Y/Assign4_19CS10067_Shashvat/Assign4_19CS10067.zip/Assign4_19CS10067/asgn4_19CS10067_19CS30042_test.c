int main()
{
	int n = 123;
	int i=0;
	/* Hi multi-line comment
	*/
	while(i<10)
	{
		printf(i);
		i++;
	}
	for(int i=0;i<10;i++)
		printf(i);

	//Single line comment
	int j = 2;
}